import { AppDataSource } from '../../src/config/database';

export const setupTestDatabase = async (): Promise<void> => {
  try {
    if (!AppDataSource.isInitialized) {
      await AppDataSource.initialize();
      console.log('✅ Test database connected');
    }
  } catch (error) {
    console.error('❌ Error connecting to test database:', error);
    throw error;
  }
};

export const cleanupTestDatabase = async (): Promise<void> => {
  try {
    if (AppDataSource.isInitialized) {
      // Limpar tabelas na ordem correta (respeitar foreign keys)
      await AppDataSource.query('TRUNCATE TABLE books CASCADE');
      await AppDataSource.query('TRUNCATE TABLE users CASCADE');
      
      // Reset sequences se necessário
      await AppDataSource.query('ALTER SEQUENCE IF EXISTS books_id_seq RESTART WITH 1');
      await AppDataSource.query('ALTER SEQUENCE IF EXISTS users_id_seq RESTART WITH 1');
    }
  } catch (error) {
    console.error('❌ Error cleaning test database:', error);
    throw error;
  }
};

export const closeTestDatabase = async (): Promise<void> => {
  try {
    if (AppDataSource.isInitialized) {
      await AppDataSource.destroy();
      console.log('✅ Test database connection closed');
    }
  } catch (error) {
    console.error('❌ Error closing test database:', error);
  }
};